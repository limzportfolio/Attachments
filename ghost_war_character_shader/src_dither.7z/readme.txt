make sure to choose 'Alpha Source' as 'From Gray Scale' when you read 'dither_packed.tga' on Unity.

parameter 'ditherTex' must be set to 'dither_packed.tga'.

parameter 'screenPixelPos' is the actual screen position range (0 to width, 0 to height).
